Control Bar Observer for COMMAND AND CONQUER GENERALS: ZERO HOUR

Author:
EA Games, xezon, Legionnaire

-----------------------------------------------------------------------------------------------
--- Regular Install ---------------------------------------------------------------------------

1. Copy all files and folders into the game install directory, for example:
   > C:\Program Files (x86)\EA Games\Command & Conquer Generals Zero Hour
   
   > On English install it would then look like so:
   > ...\EA Games\Command & Conquer Generals Zero Hour\launcherControlBarObsEnglishZH
   > ...\EA Games\Command & Conquer Generals Zero Hour\200_ControlBarObsEnglishZH.big.bak
   > ...\EA Games\Command & Conquer Generals Zero Hour\200_ControlBarObsEnglishZH.cmd

2. Run 200_ControlBarObsEnglishZH.cmd


-----------------------------------------------------------------------------------------------
--- GameRanger Install ------------------------------------------------------------------------

1. Follow step 1 from "Regular Install"

2. Start GameRanger

3. Open Edit > Options > Games

4. Select the game from the list

5. Click Browse... and navigate to generals.exe in launcher directory, for example:
   > C:\Program Files (x86)\EA Games\Command & Conquer Generals Zero Hour\
       launcherControlBarObsEnglishZH\generals.exe


-----------------------------------------------------------------------------------------------
--- Compatibility -----------------------------------------------------------------------------

This pack combines well with the Control Bar HD Remastered Pack
for upscaled controlbar textures. See: http://gentool.net/download/controlbar


-----------------------------------------------------------------------------------------------
--- Changelog ---------------------------------------------------------------------------------

v1.0:
- Initial release

v1.1
- Added white border around radar box
- Added Generals Proxy Launcher 1.8

v1.2
- Added Generals Proxy Launcher 1.9